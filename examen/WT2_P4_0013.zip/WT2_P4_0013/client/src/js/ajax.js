// TODO Opdracht 3: voeg de naam van je entiteit toe aan onderstaande Url
//       voorbeeld: const Url = 'http://localhost:3000/persons/'
const Url = 'http://localhost:3000/devlopers/'

document.getElementById("xl-1222").style.maxWidth="1222px"

// TODO Opdracht 3: Voeg event listeners toe
// Event Listeners
document.querySelector('form').addEventListener('submit', event => event.preventDefault());
document.querySelector('#toon').addEventListener('click', event => {
    let id = document.querySelector('#id').value;
    if(id) toonentiteit(id);
})
document.querySelector('#pasAan').addEventListener('click', event => {
    let id = document.querySelector('#id').value;
    if(id) pasAan(id);
})

// Functies
async function toonentiteit(id) {
    const url = 'http://localhost:3000/developers/'+ id;
    const options = {
        headers: {"content-type": "application/json"},
        method: 'GET'
    }

    const response = await fetch(url, options);
    if (response.ok) {
        console.log(JSON.stringify(await response.json()));
    } else {
        console.log('Error: ', response.statusText);
    }
}

