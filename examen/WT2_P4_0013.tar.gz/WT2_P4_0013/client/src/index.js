import bootstrap from 'bootstrap'
import 'bootstrap/dist/css/bootstrap.min.css'

// TODO opdracht 3: laad js/ajax.js
import './js/ajax';